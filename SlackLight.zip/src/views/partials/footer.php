    </div> <!-- container -->

    <footer>
        <p>&copy; by Stefan Kert 2015</p>
    </footer>

<script src="assets/jquery-1.11.2.min.js"></script>
<script src="assets/foundation/js/foundation.min.js"></script>

</body>
</html>
