<?php
    Util::redirectWithInterval("index.php", 5);
?>

<div class="large-3 large-centered columns">
    <div class="login-box">
        <div class="row">
            <div class="large-12 columns">
                <div data-alert class="alert-box success radius">
                    Registrierung erfolgreich. Sie werden in K&uuml;rze zum Login weitergeleitet.
                </div>
            </div>
        </div>
    </div>
</div>